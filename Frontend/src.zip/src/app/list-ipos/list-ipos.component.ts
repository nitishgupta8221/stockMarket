import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-ipos',
  templateUrl: './list-ipos.component.html',
  styleUrls: ['./list-ipos.component.css']
})
export class ListIposComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
