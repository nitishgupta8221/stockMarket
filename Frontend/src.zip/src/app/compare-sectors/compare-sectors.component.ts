import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-compare-sectors',
  templateUrl: './compare-sectors.component.html',
  styleUrls: ['./compare-sectors.component.css']
})
export class CompareSectorsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
