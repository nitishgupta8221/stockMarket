import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-client',
  templateUrl: './menu-client.component.html',
  styleUrls: ['./menu-client.component.css']
})
export class MenuClientComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
