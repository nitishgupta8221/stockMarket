import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ipos',
  templateUrl: './ipos.component.html',
  styleUrls: ['./ipos.component.css']
})
export class IposComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
